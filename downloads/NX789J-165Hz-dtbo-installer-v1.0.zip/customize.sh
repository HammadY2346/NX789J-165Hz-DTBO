SKIPMOUNT=true
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=false

gp() { if [ -x /system/bin/getprop ]; then /system/bin/getprop "$1" 2>/dev/null; else getprop "$1" 2>/dev/null; fi; }
nx789j() { for p in ro.product.model ro.product.vendor.model ro.product.odm.model ro.product.system.model ro.product.product.model; do case "$(gp "$p")" in NX789J*|NX809J*) return 0 ;; esac; done; return 1; }

ui_print "- Model: $(gp ro.product.model)   SDK: $(gp ro.build.version.sdk)"
nx789j || abort "! This module is for NX789J / NX809J only."
case "$(gp ro.build.version.sdk)" in 35|36) ;; *) abort "! Android 15 or 16 only." ;; esac

SLOT=$(gp ro.boot.slot_suffix)
[ -z "$SLOT" ] && SLOT=_a
BN=/dev/block/by-name
SRC=""
for c in "$BN/dtbo$SLOT" "/dev/block/bootdevice/by-name/dtbo$SLOT"; do
  [ -e "$c" ] && { SRC="$c"; break; }
done
[ -z "$SRC" ] && abort "! Could not find dtbo$SLOT partition."
ui_print "- Target partition: $SRC"

STAMP=$(date +%Y%m%d-%H%M%S)
BK=/sdcard/dtbo_stock_${SLOT}_${STAMP}.img
ui_print "- Backing up current dtbo -> $BK"
dd if="$SRC" of="$BK" 2>/dev/null || abort "! Backup failed; aborting (nothing was written)."

ui_print "- Flashing 165Hz dtbo to dtbo$SLOT ..."
dd if="$MODPATH/dtbo_165.img" of="$SRC" 2>/dev/null || abort "! Write failed. Restore with: dd if=$BK of=$SRC"
sync
ui_print "- Done. Reboot, then set peak refresh to 165 in RedMagic display settings."
ui_print "  Stock backup kept at: $BK"
ui_print "  (This module does nothing at runtime; you may remove it after reboot.)"

# clean the bundled image out of the installed module dir (not needed at runtime)
rm -f "$MODPATH/dtbo_165.img"
